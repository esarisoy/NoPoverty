class HelpRequestsManager {
    private val helpRequests = mutableListOf<HelpRequest>()

    fun addHelpRequest(helpRequest: HelpRequest) {
        helpRequests.add(helpRequest)
    }

    fun getUserHelpRequests(userId: String): List<HelpRequest> {
        return helpRequests.filter { it.userId == userId }
    }

    fun getUnresolvedHelpRequests(): List<HelpRequest> {
        return helpRequests.filter { !it.isResolved }
    }

    fun markHelpRequestAsResolved(requestId: String) {
        val request = helpRequests.find { it.requestId == requestId }
        request?.markAsResolved()
    }
}