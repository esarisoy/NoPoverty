import java.util.Scanner

class MainScreen {
    private val scanner = Scanner(System.`in`)

    fun show() {
        println("Hoş geldiniz!")
        println("1. Giriş Yap")
        println("2. Kayıt Ol")
        println("3. Yardım Taleplerini Görüntüle")
        println("4. Yardım Talebi Oluştur")
        println("5. Yardım Tekliflerini Görüntüle")
        println("6. Yardım Teklifi Kabul Et")
        println("0. Çıkış")

        print("Seçiminizi yapınız: ")
        val choice = scanner.nextInt()

        when (choice) {
            1 -> loginUser()
            2 -> registerUser()
            3 -> viewHelpRequests()
            4 -> createHelpRequest()
            5 -> viewHelpOffers()
            6 -> acceptHelpOffer()
            0 -> exit()
            else -> {
                println("Geçersiz seçim. Lütfen tekrar deneyiniz.")
                show()
            }
        }
    }

    private fun loginUser() {
        // Kullanıcı girişi işlemleri burada gerçekleştirilebilir
        println("Giriş yapılıyor...")
    }

    private fun registerUser() {
        // Kullanıcı kaydı işlemleri burada gerçekleştirilebilir
        println("Kayıt olunuyor...")
    }

    private fun viewHelpRequests() {
        // Yardım taleplerini görüntüleme işlemleri burada gerçekleştirilebilir
        println("Yardım talepleri görüntüleniyor...")
    }

    private fun createHelpRequest() {
        // Yardım talebi oluşturma işlemleri burada gerçekleştirilebilir
        println("Yardım talebi oluşturuluyor...")
    }

    private fun viewHelpOffers() {
        // Yardım tekliflerini görüntüleme işlemleri burada gerçekleştirilebilir
        println("Yardım teklifleri görüntüleniyor...")
    }

    private fun acceptHelpOffer() {
        // Yardım teklifi kabul etme işlemleri burada gerçekleştirilebilir
        println("Yardım teklifi kabul ediliyor...")
    }

    private fun exit() {
        println("Çıkış yapılıyor...")
        scanner.close()
        System.exit(0)
    }
}

fun main() {
    val mainScreen = MainScreen()
    mainScreen.show()
}