class User(
    val userId: String,
    val username: String,
    val email: String,
    val password: String,
    var phoneNumber: String,
    var address: String,
    var isAdmin: Boolean = false
) {

    fun updateProfile(phoneNumber: String, address: String) {
        this.phoneNumber = phoneNumber
        this.address = address
    }

    fun isAdmin(): Boolean {
        return isAdmin
    }
}
