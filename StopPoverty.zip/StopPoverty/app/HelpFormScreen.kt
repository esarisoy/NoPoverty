import java.util.Scanner

class HelpFormScreen {
    private val scanner = Scanner(System.`in`)

    fun show() {
        println("Yardım Talebi Oluşturma Ekranı")
        println("Lütfen aşağıdaki adımları takip ederek yardım talebinizi oluşturun.")

        print("Yardım Talebi Türünü Seçiniz: ")
        val requestType = scanner.nextLine()

        print("Yardım Talebi Açıklamasını Giriniz: ")
        val requestDescription = scanner.nextLine()

        // Yardım talebi oluşturma işlemi burada gerçekleştirilebilir
        println("Yardım talebi oluşturuluyor...")
        println("Tür: $requestType, Açıklama: $requestDescription")
    }
}

fun main() {
    val helpFormScreen = HelpFormScreen()
    helpFormScreen.show()
}