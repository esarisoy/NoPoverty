import java.util.*

class HelpRequest(
    val requestId: String = UUID.randomUUID().toString(),
    val userId: String,
    val requestType: RequestType,
    val requestDescription: String,
    val requestDate: Date = Date(),
    var isResolved: Boolean = false
) {

    fun markAsResolved() {
        isResolved = true
    }
}

enum class RequestType {
    MARKET,
    BILL,
    RENT
}