class HelpOffersManager {
    private val helpOffers = mutableListOf<HelpOffer>()

    fun addHelpOffer(helpOffer: HelpOffer) {
        helpOffers.add(helpOffer)
    }

    fun getUserHelpOffers(userId: String): List<HelpOffer> {
        return helpOffers.filter { it.userId == userId }
    }

    fun getUnacceptedHelpOffers(): List<HelpOffer> {
        return helpOffers.filter { !it.isAccepted }
    }

    fun markHelpOfferAsAccepted(offerId: String) {
        val offer = helpOffers.find { it.offerId == offerId }
        offer?.markAsAccepted()
    }
}
