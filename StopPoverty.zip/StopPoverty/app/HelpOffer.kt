import java.util.*

class HelpOffer(
    val offerId: String = UUID.randomUUID().toString(),
    val userId: String,
    val offerType: OfferType,
    val offerDescription: String,
    val offerDate: Date = Date(),
    var isAccepted: Boolean = false
) {
    // Yardım teklifini kabul edildi olarak işaretleme fonksiyonu
    fun markAsAccepted() {
        isAccepted = true
    }
}

// Yardım teklifi tipleri enum sınıfı
enum class OfferType {
    VOLUNTEERING,
    DONATION,
    SERVICE
}