import java.util.Scanner

class HelpOfferScreen {
    private val scanner = Scanner(System.`in`)

    fun show(offers: List<HelpOffer>) {
        println("Yardım Teklifleri")
        println("-------------------------------------")

        if (offers.isEmpty()) {
            println("Henüz yardım teklifi bulunmamaktadır.")
        } else {
            for ((index, offer) in offers.withIndex()) {
                println("${index + 1}. Teklif ID: ${offer.offerId}")
                println("   Tür: ${offer.offerType}")
                println("   Açıklama: ${offer.offerDescription}")
                println("   Tarih: ${offer.offerDate}")
                println("-------------------------------------")
            }

            print("Kabul etmek istediğiniz yardım teklifinin numarasını giriniz (0: Geri dön): ")
            val choice = scanner.nextInt()

            if (choice == 0) {
                return
            } else if (choice > 0 && choice <= offers.size) {
                // Yardım teklifi kabul etme işlemi burada gerçekleştirilebilir
                val selectedOffer = offers[choice - 1]
                println("Seçilen yardım teklifi kabul ediliyor: ${selectedOffer.offerId}")
            } else {
                println("Geçersiz seçim. Lütfen tekrar deneyiniz.")
                show(offers)
            }
        }
    }
}

data class HelpOffer(
    val offerId: String,
    val offerType: String,
    val offerDescription: String,
    val offerDate: String
)

fun main() {
    val offers = listOf(
        HelpOffer("1", "Yemek", "Ev yemekleri yapabilirim.", "17.02.2024"),
        HelpOffer("2", "Nakliye", "Taşıma işlerinde yardımcı olabilirim.", "16.02.2024")
    )

    val helpOfferScreen = HelpOfferScreen()
    helpOfferScreen.show(offers)
}